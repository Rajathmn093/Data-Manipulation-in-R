#1. Consider only those participants who have all the data points

df.olympic <- read.csv(file='olympic_data.csv',sep="\t",header=FALSE)

df.removed <- df.olympic[complete.cases(df.olympic),]

summary(df.olympic)
summary(df.removed)
