#3. Rank the Categories in terms of Age.(Higher the Age,Higher the Rank)

require('sqldf')

olympic <- read.csv(file='olympic_data.csv',sep="\t",header=FALSE)

ordered <- sqldf('select * from olympic order by V2 desc')

rank(ordered$V2)