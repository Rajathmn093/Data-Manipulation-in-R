#2. Rank the participants in terms : . Swimming . Table Tennis . Shooting . Gymnastics . Total Medal

require('dplyr')

df.olympic <- read.csv(file='olympic_data.csv',sep="\t",header=FALSE)

df.olympic %>% group_by(V6,V10) %>%
  distinct(V1) %>%
  filter(V6 == 'Swimming')

df.olympic %>% group_by(V6,V10) %>%
  distinct(V1) %>%
  filter(V6 == 'Table Tennis')

df.olympic %>% group_by(V6,V10) %>%
  distinct(V1) %>%
  filter(V6 == 'Shooting')

df.olympic %>% group_by(V6,V10) %>%
  distinct(V1) %>%
  filter(V6 == 'Gymnastics')
