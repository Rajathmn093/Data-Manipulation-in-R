#4. Identify Year wise top participants in terms of : . Swimming . Table Tennis . Shooting . Gymnastics . Total Medal

require(data.table)

df.olympic <- read.csv(file='olympic_data.csv',sep="\t",header=FALSE)

DT=as.data.table(df.olympic)

DT[,.SD[which.max(V10)],by=V4]
